package br.com.fiap.petshop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RadioGroup rdgCachorros;

    CheckBox ckbfemea;
    CheckBox ckbadestrado;
    CheckBox ckbvacina;

    TextView txtTotal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rdgCachorros = findViewById(R.id.rdgcachorros);
        ckbfemea = findViewById(R.id.femeas);
        ckbadestrado = findViewById(R.id.adestrado);
        ckbvacina = findViewById(R.id.vacinas);
        txtTotal = findViewById(R.id.calcular);
    }

    public void calcular(View view) {
        double dblTotal = 0;
        int selecionado = rdgCachorros.getCheckedRadioButtonId();

        switch (selecionado){
            case R.id.bordercollie:
                dblTotal = 850;
                break;
            case R.id.pitbull:
                dblTotal = 750;
                break;
            case R.id.pastoralemao:
                dblTotal = 700;
                break;
            case R.id.pastorcanadense:
                dblTotal = 800;
                break;
            }

        if(ckbfemea.isChecked()){
            dblTotal += 180.00;
        }
        if(ckbadestrado.isChecked()){
            dblTotal += 400.00;
        }
        if(ckbvacina.isChecked()){
            dblTotal += 200.00;
        }

        txtTotal.setText("R$ "+String.valueOf(dblTotal));
    }
}
